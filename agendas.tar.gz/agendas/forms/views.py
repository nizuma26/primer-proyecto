from django.shortcuts import render, redirect

from .forms import *
from .models import*

# Create your views here.
def home(request):
	return render(request, 'forms/index.html')
def listado(request):
    listx = Contacto.objects.all()
    return render(request, 'forms/list.html', {"listx": listx})
def formulario(request):
    if request.method == 'POST': # si la persona está enviando el formulario con datos
        form = ContactoForm(request.POST, request.FILES) # Bound form
        if form.is_valid():
            Contacto = form.save() # Guardar los datos en la base de datos

            return redirect ('home') 
    form = ContactoForm() # Unbound form
    return render(request, 'forms/formulario.html', {'form': form})