from django.contrib import admin
from .models import *

# Register your models here.


class ContactoAdmin(admin.ModelAdmin):
	list_display = ["cedula","nombre", "apellido", "direccion", "telefono_casa", "telefono_movil", "email",]
	list_editable = ["telefono_movil", "telefono_casa"]
	search_fields = ["cedula"]

admin.site.register(Contacto, ContactoAdmin)


