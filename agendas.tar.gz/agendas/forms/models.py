from django.db import models

# Create your models here.

class Contacto(models.Model):
	cedula = models.CharField(max_length = 8 , null=False, blank=False)
	nombre = models.CharField(max_length = 25, null=False, blank= False)
	apellido = models.CharField(max_length = 25, null=False, blank= False)
	direccion = models.TextField(null=False, blank= False)
	telefono_casa = models.CharField(max_length = 14, null=False, blank= False)
	telefono_movil = models.CharField(max_length = 14, null=False, blank= False)
	email = models.EmailField(null=False, blank= False)


	def __str__(self):
		return self.nombre